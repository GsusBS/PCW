
# Jesus
Domingo: formulario de inicio del juego hecho, a falta de refinarlo un poco
El mensaje modal deberia no dejar al usuario seleccionar otra cosa que no sea cerrar
y habría que revisar que el formulario funcione bien



# Ander


